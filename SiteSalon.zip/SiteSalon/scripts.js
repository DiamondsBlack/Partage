document.addEventListener('DOMContentLoaded', function() {
    console.log("Le site est prêt !");
});

function handleSubmit(event) {
    event.preventDefault();
    
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;
    const lastName = document.getElementById('lastName').value;
    const firstName = document.getElementById('firstName').value;
    const email = document.getElementById('email').value;
    
    const mailtoLink = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message + '\n\nNom: ' + lastName + '\nPrénom: ' + firstName)}`;
    window.location.href = mailtoLink;
}

